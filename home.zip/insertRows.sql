PRAGMA foreign_keys = ON;


INSERT INTO category (categoryId, categoryName, categoryImage) VALUES
(1, 'Science Fiction', 'science-fiction.jpg'),
(2, 'Thriller', 'thriller.jpg'),
(3, 'Non Fiction', 'non-fiction.jpg'),
(4, 'Self Help', 'self-help.jpg');

INSERT INTO book (bookId, categoryId, title, author, isbn, price, image, readNow) VALUES
(1, 1, 'Dune', 'Frank Herbert', '978-0441013593', 20.00, 'dune.jpg', 0),
(2, 1, 'Project Hail Mary', 'Andy Weir', '978-0593135228', 22.00, 'mary.jpg', 1),
(3, 1, '1984', 'George Orwell', '978-1840228021', 18.00, '1984.jpg', 0),
(4, 2, 'Gone Girl', 'Gillian Flynn', '978-0307588371', 18.00, 'gone.jpg', 1),
(5, 2, 'The Silent Patient', 'Alex Michaelides', '978-1250301697', 27.00, 'patient.jpg', 0),
(6, 2, 'The Girl with the Dragon Tattoo', 'Stieg Larsson', '978-0307454546', 17.00, 'dragon.jpg', 1),
(7, 3, 'Sapiens', 'Yuval Noah Harari', '978-0062316097', 25.00, 'sapiens.jpg', 0),
(8, 3, 'Educated', 'Tara Westover', '978-0399590504', 28.00, 'educated.jpg', 1),
(9, 3, 'Thinking, Fast and Slow', 'Daniel Kahneman', '978-0374533557', 20.00, 'thinking.jpg', 0),
(10, 4, 'Atomic Habits', 'James Clear', '978-0735211292', 27.00, 'atomic.jpg', 1),
(11, 4, 'The 7 Habits of Highly Effective People', 'Stephen R. Covey', '978-1982137274', 20.00, 'habits.jpg', 0),
(12, 4, 'How to Win Friends and Influence People', 'Dale Carnegie', '978-0671027032', 17.00, 'friends.jpg', 1);






