-- CREATE

-- Add a new book into the database


INSERT INTO book (categoryId, title, author, isbn, price, image, readNow) VALUES
(?, ?, ?, ?, ?, ?, ?);


-- READ 

-- View all categories

SELECT categoryId, categoryName
FROM category
ORDER BY categoryName;

-- View all books

SELECT title, author, price, image, readNow
FROM book
ORDER BY title;

-- View all books in a given category 

SELECT title, author, price, image readNow
FROM book
JOIN category ON book.categoryId = category.categoryId
WHERE categoryName = ?;
ORDER BY title

-- Search for books given a title keyword

SELECT title, author, price, image, readNow
FROM book
WHERE title LIKE ?
ORDER BY title;


-- UPDATE

-- Update the price of book given its bookId

UPDATE book 
SET price = ?
WHERE bookId = ?;


-- DELETE

-- Delete a book given its bookId,

DELETE FROM book
WHERE bookId = ?;







